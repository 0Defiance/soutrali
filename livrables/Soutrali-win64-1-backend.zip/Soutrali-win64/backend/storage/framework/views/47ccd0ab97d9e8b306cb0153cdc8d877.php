<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Abd Al Fattah\Desktop\PROJET SOUTRALI\backend\vendor\filament\widgets\resources\views/components/widget.blade.php ENDPATH**/ ?>