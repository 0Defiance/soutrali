<?php $__env->startSection('subject', 'Votre annonce est en ligne'); ?>

<?php $__env->startSection('body'); ?>
    <h1 style="margin:0 0 16px;font-size:22px;color:#0B5A2A;">Votre annonce est en ligne</h1>

    <p style="margin:0 0 14px;">
        Bonjour <?php echo e($listing->author->display_name); ?>,<br>
        votre annonce <strong>« <?php echo e($listing->title); ?> »</strong> est
        maintenant visible par tous les membres de Soutrali.
    </p>

    <div style="background-color:#FFF9F2;border:1px solid #DCE5DF;border-radius:10px;padding:14px 16px;margin:0 0 18px;">
        <p style="margin:0;font-size:13px;color:#5A6B62;">
            Catégorie&nbsp;: <?php echo e($listing->category->name ?? '—'); ?><br>
            Commune&nbsp;: <?php echo e($listing->commune->name ?? '—'); ?>

        </p>
    </div>

    <p style="text-align:center;margin:26px 0;">
        <a href="<?php echo e($url); ?>"
           style="display:inline-block;background-color:#037C30;color:#FFFFFF;text-decoration:none;padding:13px 26px;border-radius:8px;font-weight:700;font-family:'Segoe UI',Arial,sans-serif;">
            Voir mon annonce
        </a>
    </p>

    <p style="margin:0;color:#5A6B62;font-size:13px;">
        Les messages des intéressés arrivent dans la messagerie interne de
        Soutrali, depuis votre espace « Mon profil ».
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Abd Al Fattah\Desktop\PROJET SOUTRALI\backend\resources\views/emails/listing-published.blade.php ENDPATH**/ ?>